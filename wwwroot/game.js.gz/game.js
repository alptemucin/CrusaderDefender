'use strict';
(()=>{
let N=21, RANGE=4, COL={}, TOWERS={}, WAVES=[], KEYS=[];
const cv=document.getElementById('cv');let ctx=cv.getContext('2d');
const $=id=>document.getElementById(id);
const inspectEl=$('insp'),iconCache=new Map();
const spriteImages={};
const archerSheet=document.createElement('img');archerSheet.src='/assets/archer-animation-v1.png';
for(const key of ['archer-v1','rbg-team-v1']){const img=document.createElement('img');img.src=`/assets/${key}.png`;img.onload=()=>{iconCache.clear();towerListSignature='';if(S){renderPanel();renderTowerCards();}};spriteImages[key]=img;}
const spriteFor=u=>u.kind==='tower'?(u.type==='RBG'?spriteImages['rbg-team-v1']:null):u.color==='W'?spriteImages['archer-v1']:null;
let T=30, G=null, S=null, revision=0, runId=null, busy=false;
let requestSequence=0, appliedSequence=0, historyRun=null, historyBusy=false, savedRun=null;
let selectedUnitId=null,towerListSignature='';
let mergeVisuals=[];
const motion=new CrusaderMotion.Buffer(),weaponMotion=new Map();
const camera=new CrusaderMotion.Camera();
let viewWidth=735,viewHeight=735,drag=null,suppressClick=false;
let lastServerTime=0,clockOffset=0,lastEffectId=0,shots=[],displayEnemies=[],renderTime=0,frameDt=1/60;
const weaponNames={R:'Topçu',B:'Buz okçusu',D:'Mancınıkçı',W:'Okçu',P:'Yaylım okçusu',G:'Mehterci'};
const weaponFor=u=>u.kind==='tower'?(u.type==='RBG'?'cannon':'archer'):
  ({R:'cannon',B:'archer',D:'catapult',W:'archer',P:'volley',G:'drummer'}[u.color]);
const units=()=>G.grid.flat().filter(t=>t.unit).map(t=>t.unit);
const attackers=()=>units(); // Used only to draw support links.
const statsOf=u=>u.stats;
const mergePairs=()=>S.pairs;
const byId=id=>units().concat(S.pending).find(u=>u.id===+id);
function toast(message){
  const el=$('toast');el.textContent=message;el.style.opacity=1;
  clearTimeout(toast.timer);toast.timer=setTimeout(()=>el.style.opacity=0,2000);
}
async function refreshHistory(){
  if(historyBusy)return;
  historyBusy=true;
  try{
    const response=await fetch('/api/results');
    if(!response.ok)throw new Error('Oyun geçmişi alınamadı.');
    const results=await response.json();$('history').replaceChildren();
    if(results.some(r=>r.id===runId)){savedRun=runId;if(S?.over)$('backendStatus').textContent='Oyun sonucu sunucuda kaydedildi.';}
    for(const result of results){
      const row=document.createElement('p');
      row.textContent=`${result.outcome==='win'?'Zafer':'Yenilgi'} · Tur ${result.turn} · Can ${result.lives} · ${new Date(result.createdAt).toLocaleString('tr-TR')}`;
      $('history').append(row);
    }
    if(!results.length)$('history').textContent='Henüz tamamlanmış oyun yok.';
  }catch(error){$('history').textContent=error.message;}
  finally{historyBusy=false;}
}
function accept(snapshot, sequence){
  if(sequence<appliedSequence)return;
  appliedSequence=sequence;
  const hover=S?.hover, highlighted=S?.hl?.id;
  const previousPhase=S?.phase, previousRun=runId;
  const previousRevision=revision;
  const received=performance.now();
  const previousUnits=G?units().map(u=>({...u})):[];
  G=snapshot.map;S=snapshot.state;revision=snapshot.revision;runId=snapshot.runId;
  if(previousRun===runId)for(const u of units()){
    const old=previousUnits.find(p=>p.id===u.id);
    if(old&&u.lvl>old.lvl)mergeVisuals.push({x:u.x,y:u.y,lvl:u.lvl,at:received});
  }
  else mergeVisuals=[];
  lastServerTime=snapshot.serverTimeMs;
  if(previousRun!==runId){motion.clear();weaponMotion.clear();shots=[];lastEffectId=0;clockOffset=received-lastServerTime;renderTime=lastServerTime-120;}
  else clockOffset=Math.min(clockOffset,received-lastServerTime);
  if(S.phase==='wave')motion.push(lastServerTime,S);else motion.clear();
  N=snapshot.rules.n;RANGE=snapshot.rules.range;COL=snapshot.rules.colors;
  TOWERS=snapshot.rules.towers;WAVES=snapshot.rules.waves;KEYS=Object.keys(COL);
  // Reconnect JSON unit references only for selection highlights.
  const canonical=new Map(units().map(u=>[u.id,u]));
  S.pending=S.pending.map(u=>canonical.get(u.id)||u);
  S.pairs=S.pairs.map(pair=>pair.map(u=>canonical.get(u.id)||u));
  if(S.pick)S.pick.cands=S.pick.cands.map(u=>canonical.get(u.id)||u);
  for(const u of units())u.buffTarget=canonical.get(u.buffTargetId)||null;
  for(const f of S.fx){
    if(f.id<=lastEffectId)continue;
    lastEffectId=f.id;
    const duration=f.k==='beam'?.35:f.k==='ring'?.45:.4;
    const source=canonical.get(f.sourceId),born=lastServerTime-(duration-f.t)*1000;
    shots.push({...f,born,weapon:source?weaponFor(source):'archer'});
    if(source){
      const target=Math.atan2(f.y2-f.y1,f.x2-f.x1),previous=weaponMotion.get(source.id);
      weaponMotion.set(source.id,{angle:previous?.angle??target,target,fired:born});
    }
  }
  S.hover=previousRun===runId?hover:null;S.hl=byId(highlighted)||null;
  document.querySelectorAll('[data-sp]').forEach(b=>b.classList.toggle('on',+b.dataset.sp===S.speed));
  if(previousRevision!==revision||previousRun!==runId)renderPanel();
  if(selectedUnitId&&!canonical.has(selectedUnitId))selectedUnitId=null;
  renderTowerCards();renderInspect();$('hLives').textContent=S.lives;
  $('turnPhase').textContent=({place:'İnşa',choose:'Birlik seçimi',ready:'Hazır',wave:'Savaş',over:S.over==='win'?'Zafer':'Yenilgi'})[S.phase];
  $('hEn').textContent=S.enemies.length+S.spawnLeft;
  if(previousRun!==runId){resize();renderLegend();}
  $('backendStatus').textContent=S.over?(savedRun===runId?'Oyun sonucu sunucuda kaydedildi.':'Oyun bitti. Sonuç sunucuda kaydediliyor.'):'C# oyun sunucusu bağlı.';
  if(S.over&&(previousPhase!=='over'||historyRun!==runId)){
    historyRun=runId;setTimeout(refreshHistory,400);
  }
}
async function request(url, options){
  const response=await fetch(url,options);
  const data=await response.json();
  if(!response.ok){const error=new Error(data.error||'Sunucu isteği başarısız.');error.status=response.status;throw error;}
  return data;
}
async function send(command){
  if(!S||busy)return;
  busy=true;
  const sequence=++requestSequence;
  try{
    accept(await request('/api/game/commands',{method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({...command,revision})}),sequence);
  }catch(error){toast(error.message);$('backendStatus').textContent='Hamle uygulanamadı. Sunucu durumu yenilenecek.';}
  finally{busy=false;}
}
async function poll(){
  if(!busy){
    const sequence=++requestSequence;
    try{accept(await request('/api/game'),sequence);}
    catch(error){
      $('backendStatus').textContent=error.status===410?'Oturum sona erdi. Oyunu yeniden bağla.':'Sunucu bağlantısı kesildi. Yeniden deneniyor…';
      if(error.status===410){$('reconnect').hidden=false;return;}
    }
  }
  setTimeout(poll,S?.phase==='wave'?75:250);
}
async function connect(){
  $('reconnect').hidden=true;
  try{
    const sequence=++requestSequence;
    accept(await request('/api/game',{method:'POST'}),sequence);
    void refreshHistory();void poll();
  }catch(error){$('backendStatus').textContent='Sunucuya bağlanılamadı. ASP.NET Core uygulamasını başlat.';$('reconnect').hidden=false;}
}
$('reconnect').onclick=connect;
$('refreshHistory').onclick=refreshHistory;

/* ---------- drawing ---------- */
// Presentation only: Seljuk stonework and tile motifs, Crusader unit silhouettes.
const THEME={stone:'#888e94',stoneLight:'#d2d6da',stoneDark:'#525a63',turquoise:'#35e2cc',gold:'#ffcc68',floor:'#eeeed2'};
let floorCanvas=null,floorKey='';
function drawFloor(){
  const W=N*T,dpr=window.devicePixelRatio||1,key=`${W}:${dpr}`;
  if(key!==floorKey){
    floorKey=key;floorCanvas=document.createElement('canvas');floorCanvas.width=W*dpr;floorCanvas.height=W*dpr;
    const c=floorCanvas.getContext('2d');c.setTransform(dpr,0,0,dpr,0,0);
    c.fillStyle=THEME.floor;c.fillRect(0,0,W,W);
    for(let y=0;y<N;y++)for(let x=0;x<N;x++){
      c.fillStyle=(x+y)%2?'#b1b8a0':'#c9cdbb';c.fillRect(x*T,y*T,T,T);
    }
  }
  ctx.drawImage(floorCanvas,0,0,W,W);
}
function drawWall(tile){
  const x=tile.x*T,y=tile.y*T,p=T*.065,w=T-p*2,high=tile.obs||tile.rock?.up;
  const color=tile.rock?COL[tile.rock.color].hex:null,base=color?mix(color,.62,'#87909a'):THEME.stone;
  const depth=T*(high ? .18 : .10),cut=T*.07,frontY=y+p+depth;
  // Cut stone silhouette, dark mortar, beveled cap and offset cast shadow.
  ctx.save();ctx.fillStyle='#1e272c38';ctx.fillRect(x+p+T*.06,y+p+T*.10,w,w);
  ctx.beginPath();ctx.moveTo(x+p+cut,y+p);ctx.lineTo(x+T-p-cut,y+p);ctx.lineTo(x+T-p,y+p+cut);ctx.lineTo(x+T-p,y+T-p);ctx.lineTo(x+p,y+T-p);ctx.lineTo(x+p,y+p+cut);ctx.closePath();
  ctx.fillStyle='#343c45';ctx.fill();ctx.strokeStyle='#2d333b';ctx.lineWidth=Math.max(1,T*.045);ctx.stroke();
  const rows=high?3:2,height=w-depth,rowHeight=height/rows;
  for(let row=0;row<rows;row++){
    const offset=row%2?w*.24:0;
    for(let col=-1;col<3;col++){
      const left=Math.max(0,col*w*.5+offset),right=Math.min(w,(col+1)*w*.5+offset);
      if(right<=left)continue;
      const seed=(tile.x*7+tile.y*11+row*3+col+20)%5;
      ctx.fillStyle=mix(base,.84+seed*.025,'#333d49');ctx.fillRect(x+p+left+1,frontY+row*rowHeight+1,right-left-2,rowHeight-2);
      ctx.strokeStyle=mix(base,.65,'#edf0f2');ctx.lineWidth=.75;ctx.beginPath();ctx.moveTo(x+p+left+2,frontY+row*rowHeight+rowHeight-2);ctx.lineTo(x+p+left+2,frontY+row*rowHeight+2);ctx.lineTo(x+p+right-2,frontY+row*rowHeight+2);ctx.stroke();
    }
  }
  ctx.beginPath();ctx.moveTo(x+p+cut,y+p);ctx.lineTo(x+T-p-cut,y+p);ctx.lineTo(x+T-p,frontY);ctx.lineTo(x+p,frontY);ctx.closePath();ctx.fillStyle=mix(base,.70,'#e6e9ec');ctx.fill();
  ctx.strokeStyle=mix(base,.4,'#ffffff');ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(x+p+cut,y+p+1);ctx.lineTo(x+T-p-cut,y+p+1);ctx.stroke();
  if(high){ctx.strokeStyle=mix(base,.5,'#303944');ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(x+T*.35,y+p+1);ctx.lineTo(x+T*.38,frontY);ctx.moveTo(x+T*.7,y+p+1);ctx.lineTo(x+T*.68,frontY);ctx.stroke();}
  // A small chipped corner adds texture without an emblem.
  ctx.fillStyle=mix(base,.55,'#242d37');ctx.beginPath();ctx.moveTo(x+T-p,y+T*.72);ctx.lineTo(x+T-p-T*.07,y+T*.77);ctx.lineTo(x+T-p,y+T*.81);ctx.fill();ctx.restore();
}
function drawGate(x,y,index){
  const X=x*T,Y=y*T,col=index===0?'#ff7465':index===4?'#32e0c8':'#ffcf70';
  ctx.save();ctx.fillStyle='#24323940';ctx.fillRect(X+T*.16,Y+T*.20,T*.76,T*.76);
  // Minimal angular portal: beveled grey frame, dark passage, restrained accent.
  ctx.beginPath();ctx.moveTo(X+T*.12,Y+T*.88);ctx.lineTo(X+T*.12,Y+T*.26);ctx.lineTo(X+T*.28,Y+T*.10);ctx.lineTo(X+T*.72,Y+T*.10);ctx.lineTo(X+T*.88,Y+T*.26);ctx.lineTo(X+T*.88,Y+T*.88);ctx.closePath();ctx.fillStyle='#8e99a4';ctx.fill();ctx.strokeStyle='#323e49';ctx.lineWidth=2;ctx.stroke();
  ctx.beginPath();ctx.moveTo(X+T*.30,Y+T*.88);ctx.lineTo(X+T*.30,Y+T*.32);ctx.lineTo(X+T*.40,Y+T*.23);ctx.lineTo(X+T*.60,Y+T*.23);ctx.lineTo(X+T*.70,Y+T*.32);ctx.lineTo(X+T*.70,Y+T*.88);ctx.closePath();ctx.fillStyle='#192c36';ctx.fill();
  ctx.strokeStyle='#e1e5e5';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(X+T*.15,Y+T*.82);ctx.lineTo(X+T*.15,Y+T*.28);ctx.lineTo(X+T*.30,Y+T*.13);ctx.lineTo(X+T*.70,Y+T*.13);ctx.stroke();
  ctx.strokeStyle=col;ctx.lineWidth=Math.max(1.5,T*.055);ctx.beginPath();ctx.moveTo(X+T*.38,Y+T*.26);ctx.lineTo(X+T*.62,Y+T*.26);ctx.moveTo(X+T*.31,Y+T*.9);ctx.lineTo(X+T*.69,Y+T*.9);ctx.stroke();
  ctx.fillStyle='#f5f5e9';ctx.font=`600 ${Math.round(T*.32)}px 'IBM Plex Sans',sans-serif`;ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText(index,X+T*.5,Y+T*.59);ctx.restore();
}
function drawWeapon(u,X,Y,size){
  const weapon=weaponFor(u),color=COL[u.color].hex;
  let pose=weaponMotion.get(u.id);
  if(!pose){pose={angle:-Math.PI/2,target:-Math.PI/2,fired:-Infinity};weaponMotion.set(u.id,pose);}
  const delta=Math.atan2(Math.sin(pose.target-pose.angle),Math.cos(pose.target-pose.angle));
  pose.angle+=delta*(1-Math.exp(-14*frameDt));
  const age=(renderTime-pose.fired)/1000,kick=age>=0&&age<.20?Math.sin(age/.20*Math.PI)*size*.15:0;
  ctx.save();ctx.translate(X,Y);ctx.rotate(pose.angle+Math.PI/2);ctx.lineCap='round';ctx.lineJoin='round';
  ctx.strokeStyle='#172632';ctx.lineWidth=2;ctx.fillStyle=color;
  if(weapon==='cannon'){
    ctx.fillStyle='#344450';ctx.fillRect(-size*.74,size*.03,size*1.48,size*.50);
    for(const x of [-size*.66,size*.66]){ctx.beginPath();ctx.arc(x,size*.32,size*.22,0,Math.PI*2);ctx.fill();ctx.stroke();}
    ctx.fillStyle=color;ctx.fillRect(-size*.29,-size*.85+kick,size*.58,size*1.07);ctx.strokeRect(-size*.29,-size*.85+kick,size*.58,size*1.07);
    ctx.fillStyle='#172632';ctx.fillRect(-size*.21,-size*.91+kick,size*.42,size*.16);
    ctx.strokeStyle='#ffffff88';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(-size*.12,-size*.66+kick);ctx.lineTo(-size*.12,size*.05);ctx.stroke();
  }else if(weapon==='catapult'){
    ctx.fillStyle=color;ctx.beginPath();ctx.moveTo(-size*.7,size*.55);ctx.lineTo(0,-size*.35);ctx.lineTo(size*.7,size*.55);ctx.closePath();ctx.fill();ctx.stroke();
    ctx.strokeStyle='#172632';ctx.lineWidth=4;ctx.beginPath();ctx.moveTo(0,size*.4);ctx.lineTo(kick,-size*.8);ctx.stroke();
    ctx.fillStyle='#e8e0cb';ctx.beginPath();ctx.arc(kick,-size*.8,size*.20,0,Math.PI*2);ctx.fill();ctx.stroke();
  }else if(weapon==='drummer'){
    ctx.beginPath();ctx.ellipse(0,size*.10,size*.58,size*.40,0,0,Math.PI*2);ctx.fill();ctx.stroke();
    ctx.fillStyle='#dbc990';ctx.beginPath();ctx.ellipse(0,-size*.05,size*.58,size*.28,0,0,Math.PI*2);ctx.fill();ctx.stroke();
    ctx.strokeStyle=color;ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(-size*.58,-size*.6);ctx.lineTo(size*.10,size*.10);ctx.moveTo(size*.58,-size*.6);ctx.lineTo(-size*.10,size*.10);ctx.stroke();
  }else{
    ctx.strokeStyle='#172632';ctx.lineWidth=5;ctx.beginPath();ctx.arc(0,-size*.25,size*.72,Math.PI*.10,Math.PI*.90);ctx.stroke();
    ctx.strokeStyle=color;ctx.lineWidth=3;ctx.stroke();
    ctx.lineWidth=1.5;ctx.beginPath();ctx.moveTo(-size*.68,-size*.03);ctx.lineTo(0,size*.14+kick);ctx.lineTo(size*.68,-size*.03);ctx.stroke();
    ctx.strokeStyle='#172632';ctx.lineWidth=2;
    for(const offset of (weapon==='volley'?[-.22,0,.22]:[0])){const x=offset*size;ctx.beginPath();ctx.moveTo(x,size*.45);ctx.lineTo(x,-size*.77);ctx.moveTo(x-size*.13,-size*.58);ctx.lineTo(x,-size*.77);ctx.lineTo(x+size*.13,-size*.58);ctx.stroke();}
  }
  ctx.restore();
}
function drawSoldier(u,X,Y,size){
  const col=COL[u.color].hex;
  ctx.save();ctx.translate(X,Y);ctx.lineWidth=Math.max(1,size*.10);ctx.strokeStyle='#1a2632';ctx.lineCap='round';
  ctx.strokeStyle='#26313c';ctx.lineWidth=size*.23;
  ctx.beginPath();ctx.moveTo(-size*.18,size*.22);ctx.lineTo(-size*.25,size*.66);ctx.moveTo(size*.18,size*.22);ctx.lineTo(size*.25,size*.66);ctx.stroke();
  ctx.fillStyle=col;ctx.strokeStyle='#1a2632';ctx.lineWidth=Math.max(1,size*.08);
  ctx.beginPath();ctx.moveTo(-size*.38,-size*.26);ctx.lineTo(size*.38,-size*.26);ctx.lineTo(size*.30,size*.33);ctx.lineTo(-size*.30,size*.33);ctx.closePath();ctx.fill();ctx.stroke();
  ctx.strokeStyle='#d2a97f';ctx.lineWidth=size*.15;ctx.beginPath();ctx.moveTo(-size*.35,-size*.16);ctx.lineTo(-size*.50,size*.15);ctx.moveTo(size*.35,-size*.16);ctx.lineTo(size*.50,size*.15);ctx.stroke();
  ctx.fillStyle='#d2a97f';ctx.beginPath();ctx.arc(0,-size*.48,size*.22,0,Math.PI*2);ctx.fill();ctx.strokeStyle='#1a2632';ctx.lineWidth=1;ctx.stroke();
  ctx.fillStyle='#687583';ctx.beginPath();ctx.arc(0,-size*.53,size*.25,Math.PI,Math.PI*2);ctx.fill();
  ctx.fillStyle='#172632';ctx.fillRect(-size*.11,-size*.50,size*.05,size*.04);ctx.fillRect(size*.06,-size*.50,size*.05,size*.04);
  drawWeapon(u,size*.37,size*.15,size*.36);ctx.restore();
}
function drawTower(u,X,Y){
  const color=COL[u.color].hex;ctx.save();
  const raised=drawPlinth(X,Y,T*.88,T*.12,color);X=raised.x;Y=raised.y;
  ctx.fillStyle='#e0e3de';ctx.fillRect(X-T*.43,Y-T*.43,T*.86,T*.86);
  ctx.strokeStyle=color;ctx.lineWidth=2;ctx.strokeRect(X-T*.43,Y-T*.43,T*.86,T*.86);
  const colors=TOWERS[u.type].need;
  colors.forEach((color,i)=>drawSoldier({...u,id:u.id*10+i,color,kind:'soul'},X+(i-1)*T*.25,Y+(i===1?-T*.12:T*.09),T*.26));
  drawWeapon(u,X,Y+T*.18,T*.23);
  TOWERS[u.type].need.forEach((k,i)=>{ctx.fillStyle=COL[k].hex;ctx.fillRect(X+(i-1)*T*.19-T*.05,Y+T*.33,T*.1,T*.05);});
  ctx.restore();
}
function drawCrusader(e,now){
  const X=(e.x+.5)*T,Y=(e.y+.5)*T-e.hop*T*.3,giant=e.max>500;
  const phase=e.renderProgress*8+e.id,r=T*(giant ? .34 : .25),stride=Math.sin(phase)*r*.24;
  ctx.save();ctx.translate(X,Y);
  ctx.fillStyle='#080f0b66';ctx.beginPath();ctx.ellipse(0,r*.75+e.hop*T*.3,r*.95,r*.34,0,0,Math.PI*2);ctx.fill();
  ctx.save();ctx.rotate(e.renderAngle+Math.PI/2);ctx.translate(Math.sin(phase)*r*.035,-Math.abs(Math.sin(phase))*r*.10);
  if(giant){
    // Siege wagon instead of an implausibly oversized human.
    ctx.fillStyle='#796041';ctx.fillRect(-r,-r*.4,r*2,r*1.25);ctx.strokeStyle='#d3ba87';ctx.lineWidth=1;ctx.strokeRect(-r,-r*.4,r*2,r*1.25);
    ctx.strokeStyle='#3a2a20';ctx.beginPath();ctx.moveTo(-r,0);ctx.lineTo(r,0);ctx.moveTo(0,-r*.4);ctx.lineTo(0,r*.85);ctx.stroke();
    for(const x of [-r*.72,r*.72]){ctx.save();ctx.translate(x,r*.85);ctx.rotate(e.renderProgress*6);ctx.fillStyle='#24201b';ctx.beginPath();ctx.arc(0,0,r*.24,0,Math.PI*2);ctx.fill();ctx.strokeStyle='#998362';ctx.stroke();ctx.beginPath();ctx.moveTo(-r*.22,0);ctx.lineTo(r*.22,0);ctx.moveTo(0,-r*.22);ctx.lineTo(0,r*.22);ctx.stroke();ctx.restore();}
  }
  ctx.fillStyle='#343d3e';ctx.fillRect(-r*.52,r*.23+stride,r*.33,r*.54);ctx.fillRect(r*.18,r*.23-stride,r*.33,r*.54);
  ctx.fillStyle=e.shape==='d'?'#695477':e.shape==='t'?'#8e6148':'#e1d6bc';ctx.strokeStyle='#303532';ctx.lineWidth=1;
  ctx.beginPath();ctx.moveTo(-r*.52,-r*.38);ctx.lineTo(r*.52,-r*.38);ctx.lineTo(r*.7,r*.4);ctx.lineTo(-r*.7,r*.4);ctx.closePath();ctx.fill();ctx.stroke();
  ctx.fillStyle='#a93c31';ctx.fillRect(-r*.09,-r*.23,r*.18,r*.52);ctx.fillRect(-r*.3,-r*.09,r*.6,r*.15);
  // Mail coif, iron helmet and a dark horizontal visor.
  ctx.fillStyle=e.shape==='s'?'#bcc4bf':'#969f99';ctx.beginPath();ctx.arc(0,-r*.50,r*.42,Math.PI,0);ctx.lineTo(r*.42,-r*.16);ctx.lineTo(-r*.42,-r*.16);ctx.closePath();ctx.fill();ctx.stroke();
  ctx.fillStyle='#28332f';ctx.fillRect(-r*.28,-r*.45,r*.56,r*.1);ctx.strokeStyle='#e0decb';ctx.beginPath();ctx.moveTo(0,-r*.88);ctx.lineTo(0,-r*.22);ctx.stroke();
  // Shield silhouette differentiates heavy, mystic and agile units.
  const sx=-r*.73,sy=r*.08;
  ctx.beginPath();ctx.moveTo(sx-r*.31,sy-r*.45);ctx.lineTo(sx+r*.31,sy-r*.45);ctx.lineTo(sx+r*.31,sy+r*.02);ctx.lineTo(sx,sy+r*.45);ctx.lineTo(sx-r*.31,sy+r*.02);ctx.closePath();
  ctx.fillStyle=e.shape==='s'?'#8d3030':e.shape==='d'?'#514267':'#e8dfc7';ctx.fill();ctx.strokeStyle='#bb9b65';ctx.stroke();
  ctx.fillStyle=e.shape==='s'?'#e8dfc7':'#a83830';ctx.fillRect(sx-r*.06,sy-r*.30,r*.12,r*.51);ctx.fillRect(sx-r*.2,sy-r*.15,r*.4,r*.12);
  ctx.strokeStyle='#c9c8b2';ctx.lineWidth=1.5;ctx.beginPath();ctx.moveTo(r*.72,r*.4);ctx.lineTo(r*.88,-r*.9);ctx.stroke();
  if(e.shape==='d'||giant){const flutter=Math.sin(now*7+e.id)*r*.17;ctx.fillStyle=e.shape==='d'?'#6b547b':'#a64034';ctx.beginPath();ctx.moveTo(r*.88,-r*.9);ctx.quadraticCurveTo(r*1.2,-r*.8+flutter,r*1.5,-r*.75+flutter);ctx.lineTo(r*.88,-r*.45);ctx.closePath();ctx.fill();}
  if(e.shape==='t'){ctx.strokeStyle='#c39153';ctx.lineWidth=1.5;ctx.beginPath();ctx.arc(r*.7,0,r*.48,-Math.PI/2,Math.PI/2);ctx.stroke();}
  if(e.slow){ctx.strokeStyle='#9fd0ff';ctx.lineWidth=1.6;ctx.beginPath();ctx.ellipse(0,0,r*1.25,r*1.15,0,0,Math.PI*2);ctx.stroke();}
  if(e.shred){ctx.strokeStyle=COL.D.hex;ctx.lineWidth=1.6;ctx.beginPath();ctx.ellipse(0,0,r*1.4,r*1.3,0,0,Math.PI*2);ctx.stroke();}
  ctx.restore();
  const hw=T*.65;ctx.fillStyle='#422d23';ctx.fillRect(-hw/2,-r-5,hw,3);ctx.fillStyle='#da8a66';ctx.fillRect(-hw/2,-r-5,hw*Math.max(0,e.hp/e.max),3);
  ctx.restore();
}
function shapePath(c,k,x,y,r){
  c.beginPath();
  if(k==='R'){c.moveTo(x,y-r);c.lineTo(x+r*.92,y+r*.7);c.lineTo(x-r*.92,y+r*.7);c.closePath();}
  else if(k==='B'){c.arc(x,y,r*.85,0,Math.PI*2);}
  else if(k==='D'){for(let i=0;i<6;i++){const a=Math.PI/3*i+Math.PI/6;c.lineTo(x+Math.cos(a)*r*.9,y+Math.sin(a)*r*.9);}c.closePath();}
  else if(k==='W'){c.moveTo(x,y-r);c.lineTo(x+r*.75,y);c.lineTo(x,y+r);c.lineTo(x-r*.75,y);c.closePath();}
  else if(k==='P'){for(let i=0;i<10;i++){const a=-Math.PI/2+Math.PI/5*i,rr=i%2?r*.45:r;c.lineTo(x+Math.cos(a)*rr,y+Math.sin(a)*rr);}c.closePath();}
  else if(k==='G'){const w=r*.36;c.moveTo(x-w,y-r);c.lineTo(x+w,y-r);c.lineTo(x+w,y-w);c.lineTo(x+r,y-w);c.lineTo(x+r,y+w);c.lineTo(x+w,y+w);c.lineTo(x+w,y+r);c.lineTo(x-w,y+r);c.lineTo(x-w,y+w);c.lineTo(x-r,y+w);c.lineTo(x-r,y-w);c.lineTo(x-w,y-w);c.closePath();}
}
function mix(hex,a,base='#0f1117'){
  const p=h=>[1,3,5].map(i=>parseInt(h.slice(i,i+2),16));const A=p(hex),B=p(base);
  return'rgb('+A.map((v,i)=>Math.round(v*a+B[i]*(1-a))).join(',')+')';
}
function drawSoul(u,x,y,r,now){
  const col=COL[u.color].hex,pulse=1+Math.sin(now*3+u.id)*.05;
  ctx.save();
  const raised=drawPlinth(x,y,T*.88,T*.12,col);x=raised.x;y=raised.y;
  ctx.fillStyle='#25313b40';ctx.fillRect(x-T*.41,y-T*.40,T*.87,T*.87);
  ctx.fillStyle=mix(col,.28,'#bac8cf');ctx.fillRect(x-T*.44,y-T*.44,T*.88,T*.88);
  ctx.strokeStyle='#26323d';ctx.lineWidth=2;ctx.strokeRect(x-T*.44,y-T*.44,T*.88,T*.88);
  ctx.strokeStyle=col;ctx.lineWidth=2;ctx.strokeRect(x-T*.39,y-T*.39,T*.78,T*.78);
  drawSoldier(u,x,y-T*.03,T*.48);
  ctx.fillStyle='#1e303f';ctx.fillRect(x+T*.23,y+T*.23,T*.22,T*.22);
  shapePath(ctx,u.color,x+T*.34,y+T*.34,T*.085*pulse);ctx.fillStyle=col;ctx.fill();ctx.strokeStyle='#edf3f5';ctx.lineWidth=.7;ctx.stroke();
  ctx.restore();
  if(u.lvl>1){ctx.fillStyle='#1e303f';ctx.fillRect(x-T*.45,y+T*.21,T*.25,T*.25);ctx.font=`700 ${Math.max(9,Math.round(T*.25))}px ${getComputedStyle(document.body).getPropertyValue('--f-mono')}`;ctx.textAlign='center';ctx.textBaseline='middle';
    ctx.fillStyle='#ffffff';ctx.fillText(u.lvl,x-T*.325,y+T*.34);}
}
function upright(x,y,paint){
  const m=camera.matrix(viewWidth,viewHeight,N*T),det=m.a*m.d-m.b*m.c,s=m.a*1.65;
  ctx.save();ctx.translate(x,y);ctx.transform(m.d*s/det,-m.b*s/det,-m.c*s/det,m.a*s/det,0,0);paint();ctx.restore();
}
function drawIsoWall(t){
  const p=T*.09,h=T*(t.obs||t.rock?.up? .64:.36),color=t.rock?mix(COL[t.rock.color].hex,.55,'#969da2'):'#939da6';
  const top=[[t.x*T+p,t.y*T+p],[(t.x+1)*T-p,t.y*T+p],[(t.x+1)*T-p,(t.y+1)*T-p],[t.x*T+p,(t.y+1)*T-p]];
  // A vertical screen displacement corresponds to equal negative world offsets.
  const face=(points,fill)=>{ctx.beginPath();points.forEach(([x,y],i)=>i?ctx.lineTo(x,y):ctx.moveTo(x,y));ctx.closePath();ctx.fillStyle=fill;ctx.fill();ctx.strokeStyle='#38434c';ctx.lineWidth=.9;ctx.stroke();};
  const raised=top.map(([x,y])=>[x-h,y-h]);
  face([raised[1],raised[2],top[2],top[1]],mix(color,.75,'#28343d'));
  face([raised[2],raised[3],top[3],top[2]],mix(color,.85,'#49545e'));
  face(raised,mix(color,.8,'#e6e3d6'));
  ctx.strokeStyle='#48545d';ctx.lineWidth=.7;
  for(const [a,b] of [[1,2],[2,3]]){ctx.beginPath();ctx.moveTo((raised[a][0]+top[a][0])/2,(raised[a][1]+top[a][1])/2);ctx.lineTo((raised[b][0]+top[b][0])/2,(raised[b][1]+top[b][1])/2);ctx.stroke();}
}
function drawUnitSprite(u,now){
  const image=spriteFor(u);
  upright((u.x+.5)*T,(u.y+.5)*T,()=>{
    if(image?.complete&&image.naturalWidth){
      if(u.kind!=='tower'&&u.color==='W'&&archerSheet.complete&&archerSheet.naturalWidth){
        const pose=weaponMotion.get(u.id),age=pose?(renderTime-pose.fired)/1000:Infinity;
        const target=displayEnemies.filter(e=>Math.hypot(e.x-u.x,e.y-u.y)<=statsOf(u).range).sort((a,b)=>b.renderProgress-a.renderProgress)[0];
        let angle=pose?.target??0;
        if(target&&age>.32)angle=Math.atan2(target.y-u.y,target.x-u.x);
        const frame=CrusaderMotion.archerFrame(Math.cos(angle),Math.sin(angle),age,u.cd/(1+(u.buff||0)),!!target);
        // Separate planted platform and directional character. Never rotate the sprite.
        ctx.fillStyle='#28333e';ctx.beginPath();ctx.ellipse(0,T*.04,T*.38,T*.12,0,0,Math.PI*2);ctx.fill();
        ctx.fillStyle='#c6b99b';ctx.beginPath();ctx.moveTo(-T*.46,0);ctx.lineTo(0,-T*.23);ctx.lineTo(T*.46,0);ctx.lineTo(0,T*.23);ctx.closePath();ctx.fill();ctx.strokeStyle='#665b4f';ctx.lineWidth=1;ctx.stroke();
        const cw=archerSheet.naturalWidth/4,ch=archerSheet.naturalHeight/4,size=T*1.03;
        ctx.save();if(frame.flip)ctx.scale(-1,1);
        ctx.drawImage(archerSheet,frame.column*cw,frame.row*ch,cw,ch,-size*.5,-size*.91,size,size);ctx.restore();
      }else ctx.drawImage(image,-T*.59,-T*1.02,T*1.18,T*1.18);
      ctx.fillStyle='#172632';ctx.fillRect(T*.19,-T*.15,T*.35,T*.24);ctx.fillStyle='#ffe7a0';ctx.font=`700 ${T*.18}px 'IBM Plex Sans'`;ctx.textAlign='center';ctx.fillText(`Lv${u.lvl}`,T*.36,T*.02);
    }else if(u.kind==='tower')drawTower(u,0,-T*.25);else drawSoul(u,0,-T*.25,T*.36,now);
  });
}
function draw(now){
  renderTime=Math.max(renderTime,performance.now()-clockOffset-120);
  displayEnemies=motion.view(renderTime);
  const W=N*T,dpr=window.devicePixelRatio||1;
  ctx.setTransform(dpr,0,0,dpr,0,0);ctx.clearRect(0,0,viewWidth,viewHeight);
  ctx.save();const m=camera.matrix(viewWidth,viewHeight,W);ctx.transform(m.a,m.b,m.c,m.d,m.e,m.f);
  drawFloor();
  // path preview
  const nextW=WAVES[S.turn-1],pp=(S.phase==='wave'?S.wave:nextW)?.jump?S.jpath:S.path;
  if(pp){ctx.save();ctx.strokeStyle=nextW&&nextW.jump?'rgba(112,38,94,.6)':'rgba(31,66,65,.5)';ctx.lineWidth=2;ctx.setLineDash([4,5]);ctx.beginPath();
    pp.forEach(([x,y],i)=>{const X=(x+.5)*T,Y=(y+.5)*T;i?ctx.lineTo(X,Y):ctx.moveTo(X,Y);});ctx.stroke();ctx.restore();}
  // pick highlights
  // units
  const scenery=G.grid.flat().filter(t=>t.obs||t.rock||t.unit||t.cp>=0).map(t=>({depth:t.x+t.y+.5,t}));
  scenery.push(...displayEnemies.map(e=>({depth:e.x+e.y,e})));
  scenery.sort((a,b)=>a.depth-b.depth);
  for(const item of scenery){
    if(item.e){const e=item.e;upright((e.x+.5)*T,(e.y+.5)*T,()=>{ctx.translate(-(e.x+.5)*T,-(e.y+.5)*T-T*.23);drawCrusader(e,now);});continue;}
    const t=item.t;if(t.obs||t.rock)drawIsoWall(t);
    if(t.cp>=0)upright((t.x+.5)*T,(t.y+.5)*T,()=>drawGate(-.5,-.75,t.cp));
    const u=t.unit;if(!u)continue;
    const X=(u.x+.5)*T,Y=(u.y+.5)*T;
    if(u.kind==='tower'){
      drawUnitSprite(u,now);
      continue;
    }
    if(!u.revealed){
      ctx.fillStyle='#335469';ctx.fillRect(X-T*.42,Y-T*.42,T*.84,T*.84);ctx.strokeStyle='#26323d';ctx.lineWidth=2;ctx.strokeRect(X-T*.42,Y-T*.42,T*.84,T*.84);
      ctx.fillStyle='#eee0ba';ctx.font=`700 ${Math.round(T*.52)}px 'IBM Plex Sans',sans-serif`;ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText('?',X,Y+1);continue;
    }
    drawUnitSprite(u,now);
    if(S.pending.includes(u)&&u.status==='kept'){ctx.strokeStyle='#184a67';ctx.lineWidth=2;ctx.beginPath();ctx.arc(X,Y,T*.47,0,Math.PI*2);ctx.stroke();}
    if(S.phase==='choose'&&S.pending.includes(u)&&!u.status&&!S.pick){ctx.strokeStyle='rgba(24,64,73,.6)';ctx.setLineDash([3,3]);ctx.lineWidth=1;ctx.strokeRect(u.x*T+2.5,u.y*T+2.5,T-5,T-5);ctx.setLineDash([]);}
    if(u.flash>0){u.flash-=.02;ctx.strokeStyle=`rgba(255,255,255,${u.flash})`;ctx.lineWidth=2;ctx.beginPath();ctx.arc(X,Y,T*(.9-u.flash*.4),0,Math.PI*2);ctx.stroke();}
  }
  // green links
  if(S.phase==='wave')for(const u of attackers())if(u.buffTarget){ctx.strokeStyle='rgba(70,214,124,.45)';ctx.setLineDash([2,4]);ctx.lineWidth=1.5;ctx.beginPath();ctx.moveTo((u.x+.5)*T,(u.y+.5)*T);ctx.lineTo((u.buffTarget.x+.5)*T,(u.buffTarget.y+.5)*T);ctx.stroke();ctx.setLineDash([]);}
  // hover
  const h=S.hover;
  if(h){
    const t=G.grid[h[1]][h[0]];
    ctx.strokeStyle='rgba(25,78,108,.85)';ctx.lineWidth=1.5;ctx.strokeRect(h[0]*T+1,h[1]*T+1,T-2,T-2);
    const u=t.unit;
    if(u&&u.revealed){const r=statsOf(u).range;ctx.strokeStyle='rgba(25,78,108,.5)';ctx.fillStyle='rgba(25,78,108,.06)';ctx.beginPath();ctx.arc((u.x+.5)*T,(u.y+.5)*T,(r+.5)*T,0,Math.PI*2);ctx.fill();ctx.stroke();}
    else if(S.phase==='place'&&S.tool==='soul'&&!t.unit&&!t.obs&&t.cp<0){ctx.strokeStyle='rgba(25,78,108,.3)';ctx.beginPath();ctx.arc((h[0]+.5)*T,(h[1]+.5)*T,(RANGE+.5)*T,0,Math.PI*2);ctx.stroke();ctx.fillStyle='rgba(25,78,108,.4)';ctx.beginPath();ctx.arc((h[0]+.5)*T,(h[1]+.5)*T,T*.3,0,Math.PI*2);ctx.fill();}
  }
  const focused=byId(selectedUnitId)||S.hl;
  if(focused){ctx.strokeStyle='#184a67';ctx.lineWidth=2;ctx.strokeRect(focused.x*T+1,focused.y*T+1,T-2,T-2);}
  if(S.pick){
    const pulse=.5+.5*Math.sin(now*5);
    for(const u of S.pick.cands){
      const x=u.x*T,y=u.y*T;ctx.save();ctx.fillStyle=`rgba(255,207,70,${.14+.12*pulse})`;ctx.fillRect(x,y,T,T);
      ctx.strokeStyle='#182532';ctx.lineWidth=6;ctx.strokeRect(x+2,y+2,T-4,T-4);
      ctx.strokeStyle='#ffdf62';ctx.lineWidth=3;ctx.strokeRect(x+2,y+2,T-4,T-4);
      ctx.fillStyle='#182532';ctx.fillRect(x,y-T*.27,T,T*.28);ctx.fillStyle='#ffdf62';ctx.font=`700 ${Math.max(9,T*.22)}px 'IBM Plex Sans'`;ctx.textAlign='center';ctx.fillText('SEÇ',x+T/2,y-T*.06);ctx.restore();
    }
  }
  mergeVisuals=mergeVisuals.filter(v=>performance.now()-v.at<1100);
  for(const v of mergeVisuals){
    const p=(performance.now()-v.at)/1100,x=(v.x+.5)*T,y=(v.y+.5)*T;
    ctx.save();ctx.globalAlpha=1-p;ctx.strokeStyle='#ffe473';ctx.lineWidth=4*(1-p)+1;ctx.beginPath();ctx.arc(x,y,T*(.35+p*.9),0,Math.PI*2);ctx.stroke();
    for(let i=0;i<8;i++){const a=i*Math.PI/4,r=T*(.3+p);ctx.fillStyle='#fff2af';ctx.fillRect(x+Math.cos(a)*r-2,y+Math.sin(a)*r-2,4,4);}
    ctx.fillStyle='#172632';ctx.fillRect(x-T*.65,y-T*(.9+p*.3),T*1.3,T*.35);ctx.fillStyle='#ffe473';ctx.font=`700 ${Math.max(10,T*.27)}px 'IBM Plex Sans'`;ctx.textAlign='center';ctx.fillText(`Lv ${v.lvl} ↑`,x,y-T*(.65+p*.3));ctx.restore();
  }
  // enemies
  // fx
  drawShots();
  ctx.restore();
}
function drawPlinth(x,y,width,height,color){
  const dx=-height*.12,dy=-height*.35,h=width/2;
  ctx.fillStyle='#20302e40';ctx.fillRect(x-h+T*.08,y-h+T*.10,width,width);
  ctx.fillStyle=mix(color,.23,'#46505c');ctx.beginPath();ctx.moveTo(x-h,y+h);ctx.lineTo(x+h,y+h);ctx.lineTo(x+h+dx,y+h+dy);ctx.lineTo(x-h+dx,y+h+dy);ctx.closePath();ctx.fill();ctx.strokeStyle='#29343e';ctx.lineWidth=1.2;ctx.stroke();
  ctx.fillStyle=mix(color,.13,'#26323e');ctx.beginPath();ctx.moveTo(x+h,y-h);ctx.lineTo(x+h,y+h);ctx.lineTo(x+h+dx,y+h+dy);ctx.lineTo(x+h+dx,y-h+dy);ctx.closePath();ctx.fill();ctx.stroke();
  return {x:x+dx,y:y+dy};
}
function drawShots(){
  shots=shots.filter(f=>renderTime-f.born<700);
  for(const f of shots){
    const age=(renderTime-f.born)/1000;if(age<0)continue;
    ctx.save();
    if(f.k==='beam'){
      const flight=f.weapon==='cannon'||f.weapon==='catapult'?.18:.13,p=Math.min(1,age/flight);
      const lift=f.weapon==='archer'||f.weapon==='volley'? .62*(1-p)+.24*p:0;
      const x=(f.x1+(f.x2-f.x1)*p+.5-lift)*T,y=(f.y1+(f.y2-f.y1)*p+.5-lift)*T-Math.sin(p*Math.PI)*T*(f.weapon==='catapult'?1:.15);
      if(p<1){
        ctx.translate(x,y);ctx.rotate(Math.atan2(f.y2-f.y1,f.x2-f.x1));ctx.strokeStyle=f.c;ctx.fillStyle=f.c;ctx.lineWidth=1.6;
        if(f.weapon==='cannon'||f.weapon==='catapult'){ctx.beginPath();ctx.arc(0,0,T*.08,0,Math.PI*2);ctx.fill();ctx.globalAlpha=.35;ctx.fillRect(-T*.3,-1,T*.22,2);}
        else{ctx.beginPath();ctx.moveTo(-T*.24,0);ctx.lineTo(T*.12,0);ctx.moveTo(T*.04,-T*.05);ctx.lineTo(T*.12,0);ctx.lineTo(T*.04,T*.05);ctx.stroke();}
      }else if(age<flight+.22){
        ctx.globalAlpha=1-(age-flight)/.22;
        const r=T*(.08+(age-flight)*.6);
        for(let i=0;i<6;i++){const a=i*Math.PI/3;ctx.fillStyle=f.c;ctx.beginPath();ctx.arc((f.x2+.5)*T+Math.cos(a)*r,(f.y2+.5)*T+Math.sin(a)*r,Math.max(.6,T*.035),0,Math.PI*2);ctx.fill();}
      }
    }else if(f.k==='ring'&&age<.4){ctx.strokeStyle=f.c;ctx.globalAlpha=(1-age/.4)*.7;ctx.lineWidth=2;ctx.beginPath();ctx.arc((f.x+.5)*T,(f.y+.5)*T,f.r*T*(.4+age*2),0,Math.PI*2);ctx.stroke();}
    else if(f.k==='leak'&&age<.4){ctx.fillStyle='#ff6b5b';ctx.globalAlpha=(1-age/.4)*.09;ctx.fillRect(0,0,N*T,N*T);}
    ctx.restore();
  }
}

/* ---------- panel ---------- */
function svgShape(k,s=18){
  const c=COL[k].hex,h=s/2,r=s*.45;let el='';
  const pts=a=>a.map(p=>p.map(v=>v.toFixed(1)).join(',')).join(' ');
  if(k==='R')el=`<polygon points="${pts([[h,h-r],[h+r*.92,h+r*.7],[h-r*.92,h+r*.7]])}" fill="${c}"/>`;
  else if(k==='B')el=`<circle cx="${h}" cy="${h}" r="${r*.85}" fill="${c}"/>`;
  else if(k==='D'){const a=[];for(let i=0;i<6;i++){const t=Math.PI/3*i+Math.PI/6;a.push([h+Math.cos(t)*r*.9,h+Math.sin(t)*r*.9]);}el=`<polygon points="${pts(a)}" fill="#24133f" stroke="${c}" stroke-width="1.6"/>`;}
  else if(k==='W')el=`<polygon points="${pts([[h,h-r],[h+r*.75,h],[h,h+r],[h-r*.75,h]])}" fill="${c}"/>`;
  else if(k==='P'){const a=[];for(let i=0;i<10;i++){const t=-Math.PI/2+Math.PI/5*i,rr=i%2?r*.45:r;a.push([h+Math.cos(t)*rr,h+Math.sin(t)*rr]);}el=`<polygon points="${pts(a)}" fill="${c}"/>`;}
  else if(k==='G'){const w=r*.36;el=`<path d="M${h-w} ${h-r}h${2*w}v${r-w}h${r-w}v${2*w}h${-(r-w)}v${r-w}h${-2*w}v${-(r-w)}h${-(r-w)}v${-2*w}h${r-w}z" fill="${c}"/>`;}
  return`<svg width="${s}" height="${s}" viewBox="0 0 ${s} ${s}" aria-hidden="true">${el}</svg>`;
}
const soulLabel=u=>`${unitIcon(u)}<small>${unitName(u)}</small><span class="lv">Lv. ${u.lvl}</span>`;
function recipeButtons(){
  return S.recipes.map(r=>`<button data-craft="${r.key}">${TOWERS[r.key].name} kur${r.over?' <span class="warn">· fazla seviye harcanır</span>':''}</button>`).join('');
}
function toolRow(){
  return`<div class="row"><button data-tool="soul" class="${S.tool==='soul'?'on':''}">${S.phase==='place'?'Ruh koy':'Seç'}</button><button data-tool="remove" class="${S.tool==='remove'?'on':''}">Duvar kaldır</button></div>`;
}
function renderPanel(){
  $('hTurn').textContent=S.turn;$('hLives').textContent=S.lives;
  let h='';
  if(S.pick){
    h=`<h2>Karo seç</h2><p class="big">${S.pick.label}</p><p>Parlayan karolardan birine tıkla. Diğer malzemeler duvara döner.</p><div class="row"><button data-act="cancelPick">Vazgeç</button></div>`;
  }else if(S.phase==='place'){
    const r=recipeButtons();
    h=`<h2>İnşa</h2><p class="big">${S.pending.length}/5 ruh kondu</p>
    <p>Boş karoya ya da bir duvarın üstüne tıkla. Yolu kapatan karoya izin verilmez. Konmuş ruha tıklarsan geri alırsın.</p>${toolRow()}
    ${r?`<p>Haritadaki ruhlarla kurulabilir:</p><div class="row">${r}</div>`:''}`;
  }else if(S.phase==='choose'&&S.step==='keep'){
    const m=mergePairs(),r=recipeButtons();
    h=`<h2>Ruhlar açıldı</h2><p class="big">Birini tut</p><p>Tuttuğun ruh haritada kalır ve saldırır. Tıkla ya da karoyu seç.</p>
    <div class="spirit-slots">${S.pending.map(u=>`<span class="chip spirit-slot" role="button" tabindex="0" data-keep="${u.id}">${soulLabel(u)}</span>`).join('')}</div>
    ${m.length?`<p>Eş birlikler birleşebilir (birleşen tutulmuş sayılır, eşi duvara döner):</p><div class="row">${m.map((p,i)=>`<button data-merge="${i}">${unitName(p[0])} Lv ${p[0].lvl} + Lv ${p[0].lvl} → Lv ${p[0].lvl+1}</button>`).join('')}</div>`:''}
    ${r?`<p>Tarif hazır (kule tutulmuş sayılır):</p><div class="row">${r}</div>`:''}`;
  }else if(S.phase==='choose'&&S.step==='rock'){
    const need=2-S.pending.filter(p=>p.status==='rock').length;
    h=`<details class="help"><summary>Labirent ⓘ</summary><p>Seçmediğin ruhlar dağılır. Duvarın üstündeki ruh duvar olursa duvar yükselir ve zıplanamaz olur.</p></details><p class="big">${need} ruhu duvara çevir</p>
    <div class="spirit-slots">${S.pending.map(u=>`<span class="chip spirit-slot ${u.status?'dim':''}" role="button" tabindex="0" ${u.status?'':`data-rock="${u.id}"`}>${soulLabel(u)}${u.status==='kept'?' <span class="tag">tutuldu</span>':u.status==='rock'?' <span class="tag">duvar</span>':''}</span>`).join('')}</div>`;
  }else if(S.phase==='ready'){
    const r=recipeButtons();
    h=`<h2>Hazır</h2><p class="big">Savunma hazır</p><p>Duvarları istersen kaldırabilirsin. Hazır olunca başlat (<kbd>Boşluk</kbd>).</p>
    <div class="row"><button class="primary" data-act="start">Dalgayı başlat</button></div>${toolRow()}
    ${r?`<div class="row">${r}</div>`:''}`;
  }else if(S.phase==='wave'){
    h=`<h2>Savaş</h2><p class="big">Hisarı savun</p><p>Düşmanlar 0 → 4 sırasıyla yürüyor.</p>`;
  }else if(S.phase==='over'){
    h=S.over==='win'?`<h2>Kat bitti</h2><p class="big">15 dalga geçildi</p><p>Kalan can: <b>${S.lives}</b></p>`:`<h2>Kaybettin</h2><p class="big">Dalga ${S.turn}'de düştün</p>`;
    h+=`<div class="row"><button class="primary" data-act="again">Aynı haritada tekrar</button><button data-act="new">Yeni harita</button></div>`;
  }
  if(!S.pick&&(S.phase==='place'||(S.phase==='choose'&&S.step==='rock'))){
    const m=mergePairs();
    h+=`<h2>Birlik birleştir</h2><p>Aynı renk ve seviyedeki iki ruh veya aynı tür ve seviyedeki iki burç bir seviye yükselir. Kalacak karoyu seç; diğeri duvara dönüşür.</p>${m.length?`<div class="row">${m.map((p,i)=>`<button data-merge="${i}">${unitName(p[0])} Lv ${p[0].lvl} + Lv ${p[0].lvl} → Lv ${p[0].lvl+1}</button>`).join('')}</div>`:'<p>Şu anda birleşebilecek eş yok.</p>'}`;
  }
  if(S.phase==='place')h+=`<div class="spirit-slots">${Array.from({length:5},(_,i)=>`<div class="chip spirit-slot"><span class="mystery">?</span><small>${i<S.pending.length?'Yerleştirildi':'Ruh bekleniyor'}</small></div>`).join('')}</div>`;
  $('phase').innerHTML=h;
  const w=WAVES[Math.min(S.turn,15)-1];
  const traits=[w.armor?`Zırh ${w.armor}`:'',w.mr?`Büyü direnci %${Math.round(w.mr*100)}`:'',w.jump?'Zıplar: tek kat duvarları aşar':'',w.speed>=3?'Hızlı':w.speed<1.8?'Yavaş':''].filter(Boolean);
  $('wave').innerHTML=`<h2 class="wave-title" tabindex="0" title="${w.name}: ${w.n} düşman, ${w.hp} can. ${traits.join('. ')||'Özel savunması yok.'}">⚔ ${S.phase==='wave'?'Bu dalga':'Sıradaki dalga'} · ${S.turn} ⓘ</h2><p>${w.name}</p>
  <div class="wave-metrics"><span title="Düşman sayısı">⚔ ${w.n}</span><span title="Düşman canı">♥ ${w.hp}</span><span title="Hız">➜ ${w.speed} karo/sn</span></div>
  <div class="row">${traits.map(t=>`<span class="tag">${t}</span>`).join('')||'<span class="tag">Savunmasız</span>'}</div>
  ${w.armor>=8?'<p>Fiziksel hasar az işler; büyü ya da zırh kırma öne çıkar.</p>':w.mr>=.4?'<p>Büyü hasarı az işler; fiziksel öne çıkar.</p>':w.jump?'<p>Yolu yükseltilmiş duvarlarla kapatmazsan kestirme yapar.</p>':''}`;
}
const formatPower=value=>Number(value||0).toLocaleString('tr-TR',{maximumFractionDigits:1});
const unitName=u=>u.kind==='tower'?TOWERS[u.type].name:weaponNames[u.color];
function unitIcon(u){
  const sprite=spriteFor(u);if(sprite)return `<img class="unit-icon" src="${sprite.src}" alt="${unitName(u)}">`;
  const key=`${u.kind}:${u.type}:${u.color}:${u.lvl}`;
  if(!iconCache.has(key)){
    const canvas=document.createElement('canvas');canvas.width=96;canvas.height=96;
    const oldCtx=ctx,oldT=T,oldDt=frameDt;ctx=canvas.getContext('2d');T=80;frameDt=0;
    try{if(u.kind==='tower')drawTower({...u,id:-100},48,48);else drawSoul({...u,id:-101},48,48,29,0);iconCache.set(key,canvas.toDataURL());}
    finally{ctx=oldCtx;T=oldT;frameDt=oldDt;}
  }
  return `<img class="unit-icon" src="${iconCache.get(key)}" alt="${unitName(u)}">`;
}
function renderTowerCards(){
  const towers=units().filter(u=>u.revealed),signature=JSON.stringify(towers.map(u=>[u.id,u.lvl,u.powerPerSecond,u.buff,selectedUnitId===u.id]));
  if(signature===towerListSignature)return;towerListSignature=signature;
  $('towerPanel').append(inspectEl);
  $('towerCards').innerHTML=towers.length?towers.map(u=>`<button class="tower-summary ${selectedUnitId===u.id?'selected':''}" data-inspect="${u.id}" aria-expanded="${selectedUnitId===u.id}" style="--unit-color:${COL[u.color].hex}">${unitIcon(u)}<b>${unitName(u)}</b><span>Lv. ${u.lvl}</span><small>(${u.x}, ${u.y})</small><strong>${formatPower(u.powerPerSecond)} hasar/sn</strong></button>`).join(''):'<p>Birlikler açıldığında burada görünür.</p>';
  document.querySelector(`#towerCards [data-inspect="${selectedUnitId}"]`)?.after(inspectEl);
}
function renderInspect(){
  const pinned=byId(selectedUnitId),h=pinned?[pinned.x,pinned.y]:S.hover;
  inspectEl.hidden=!pinned;
  let html='<h2>İncele</h2>';
  if(!h){$('insp').innerHTML=html+'<p>Bir kulenin üstüne gel veya kartına tıklayarak bilgilerini sabitle.</p>';return;}
  const t=G.grid[h[1]][h[0]],u=t.unit;
  if(u?.revealed){
    const s=statsOf(u),interval=u.attackInterval??s.cd/(1+(u.buff||0)),power=u.powerPerSecond??s.dmg/interval;
    const details=[s.splash?`Alan etkisi: ${formatPower(s.splash)} karo`:'',s.slow?`Yavaşlatma: %${Math.round(s.slow*100)}`:'',s.shred?`Zırh kırma: ${formatPower(s.shred)} / vuruş`:'',s.multi?`Aynı anda ${s.multi} hedef`:'',s.support?`Destek: +%${Math.round(s.support*100)} saldırı hızı`:''].filter(Boolean);
    html+=`<div class="row"><span style="color:${COL[u.color].hex}">${svgShape(u.color,22)}</span><p class="big">${unitName(u)}</p><span class="tag">Lv. ${u.lvl}</span></div><p>${u.kind==='tower'?TOWERS[u.type].role:COL[u.color].verb}</p>
    <div class="power-grid"><div><strong>${formatPower(power)}</strong><small>Güncel ham hasar / sn</small></div><div><strong>${formatPower(s.dmg)}</strong><small>Vuruş hasarı · ${s.dt==='p'?'fiziksel':'büyü'}</small></div></div>
    <dl class="stat"><dt>Seviye</dt><dd>${u.lvl}</dd><dt>Atış aralığı</dt><dd>${formatPower(interval)} sn</dd><dt>Menzil</dt><dd>${formatPower(s.range)} karo</dd><dt>Aktif hız desteği</dt><dd>+%${Math.round((u.buff||0)*100)}</dd><dt>Bu dalga hasarı</dt><dd>${formatPower(u.dmgThis)}</dd><dt>Son dalga hasarı</dt><dd>${formatPower(u.dmgLast)}</dd><dt>Konum</dt><dd>${u.x}, ${u.y}</dd></dl>
    ${details.length?`<div class="row">${details.map(text=>`<span class="tag">${text}</span>`).join('')}</div>`:''}
    <p style="font-size:11px">Ham güç hız desteğini içerir; düşman direnci, alan ve çoklu hedef etkileri bu sayıya dahil değildir.</p>
    ${S.pending.includes(u)?'<p class="warn">Birlik seçimi henüz tamamlanmadı.</p>':''}
    ${pinned?'<button data-unpin="1">Seçimi bırak</button>':`<button data-inspect="${u.id}">Kartı sabitle</button>`}`;
  }else if(u)html+='<p class="big">Açılmamış birlik</p><p>5 ruh konunca renk, seviye ve güç açılır.</p>';
  else if(t.rock)html+=`<p class="big">${t.rock.up?'Yükseltilmiş duvar':'Duvar'}</p><p>${COL[t.rock.color].name} · ${t.rock.up?'Keşifçiler aşamaz.':'Keşifçiler üzerinden atlar.'}</p><p>İnşa aşamasında ücretsiz kaldırılabilir.</p>`;
  else if(t.obs)html+='<p class="big">Sabit duvar</p><p>Kaldırılamaz; keşifçiler üzerinden geçemez.</p>';
  else if(t.cp>=0)html+=`<p class="big">Kapı ${t.cp}</p><p>${t.cp===0?'Haçlı birliklerinin giriş noktası.':t.cp===4?'İç hisar; buraya ulaşan düşman can götürür.':'Birlikler sırayla bu geçitten geçer.'}</p>`;
  else html+=`<p class="big">Boş karo</p><p>Konum: ${h[0]}, ${h[1]}</p>`;
  $('insp').innerHTML=html;
}
function renderLegend(){
$('legend').innerHTML=KEYS.map(k=>`${svgShape(k)}<span>${weaponNames[k]} · ${COL[k].name}<br><small>${COL[k].verb}</small></span><span class="t">${COL[k].dt==='p'?'fiziksel':'büyü'}</span>`).join('')+
  `<span></span><span style="grid-column:2/4;color:var(--muted);font-size:12px">Tarifler: <b style="color:var(--fg)">RBG</b> = Kırmızı+Mavi+Yeşil · <b style="color:var(--fg)">WPD</b> = Beyaz+Mor-pembe+Siyah-mor</span>`;


}


/* ---------- input: commands only; all rules run in C# ---------- */
document.addEventListener('click',ev=>{
  if(!S)return;
  const b=ev.target.closest('[data-act],[data-tool],[data-keep],[data-rock],[data-merge],[data-craft],[data-sp],[data-inspect],[data-unpin]');
  if(!b)return;const d=b.dataset;
  if(d.inspect){selectedUnitId=selectedUnitId===+d.inspect?null:+d.inspect;S.hover=null;towerListSignature='';renderTowerCards();renderInspect();}
  else if(d.unpin){selectedUnitId=null;S.hover=null;towerListSignature='';renderTowerCards();renderInspect();}
  else if(d.sp)void send({action:'speed',speed:+d.sp});
  else if(d.act)void send({action:d.act});
  else if(d.tool)void send({action:'tool',tool:d.tool});
  else if(d.keep)void send({action:'keep',id:+d.keep});
  else if(d.rock)void send({action:'rock',id:+d.rock});
  else if(d.merge)void send({action:'merge',index:+d.merge});
  else if(d.craft)void send({action:'craft',recipe:d.craft});
});
document.addEventListener('mouseover',ev=>{
  if(!S)return;const c=ev.target.closest('[data-keep],[data-rock]');
  S.hl=c?byId(c.dataset.keep||c.dataset.rock):null;
});
$('newMap').onclick=()=>void send({action:'new'});
function tileAt(ev){
  const p=pointerAt(ev),world=camera.world(p.x,p.y,viewWidth,viewHeight,N*T),x=Math.floor(world.x/T),y=Math.floor(world.y/T);
  return x>=0&&y>=0&&x<N&&y<N?[x,y]:null;
}
function pointerAt(ev){const r=cv.getBoundingClientRect();return {x:(ev.clientX-r.left)*viewWidth/r.width,y:(ev.clientY-r.top)*viewHeight/r.height};}
cv.addEventListener('wheel',ev=>{
  ev.preventDefault();const p=pointerAt(ev),delta=ev.deltaY*(ev.deltaMode===1?16:ev.deltaMode===2?viewHeight:1);
  camera.zoomAt(Math.exp(-Math.max(-300,Math.min(300,delta))*.0015),p.x,p.y,viewWidth,viewHeight,N*T);
},{passive:false});
cv.addEventListener('pointerdown',ev=>{if(!ev.shiftKey&&ev.button!==1)return;ev.preventDefault();drag={...pointerAt(ev),id:ev.pointerId};suppressClick=true;cv.setPointerCapture(ev.pointerId);cv.style.cursor='grabbing';});
cv.addEventListener('pointermove',ev=>{if(!drag)return;const p=pointerAt(ev);camera.panX+=p.x-drag.x;camera.panY+=p.y-drag.y;drag={...p,id:drag.id};});
function endDrag(){if(!drag)return;drag=null;cv.style.cursor='';}
cv.addEventListener('pointerup',endDrag);cv.addEventListener('pointercancel',endDrag);
const resetView=$('resetView');if(resetView)resetView.onclick=()=>camera.reset();
cv.addEventListener('mousemove',ev=>{if(!S)return;const t=tileAt(ev);if(String(t)!==String(S.hover)){S.hover=t;renderInspect();}});
cv.addEventListener('mouseleave',()=>{if(S){S.hover=null;renderInspect();}});
cv.addEventListener('click',ev=>{
  if(suppressClick||ev.shiftKey){suppressClick=false;return;}
  if(!S)return;const p=tileAt(ev);if(!p)return;
  const clicked=G.grid[p[1]][p[0]].unit;
  if(!S.pick&&clicked?.revealed){
    selectedUnitId=selectedUnitId===clicked.id?null:clicked.id;S.hover=null;towerListSignature='';renderTowerCards();renderInspect();
    document.querySelector(`[data-inspect="${clicked.id}"]`)?.scrollIntoView?.({block:'nearest',behavior:'smooth'});
    if(!S.pending.includes(clicked)||clicked.status)return;
  }
  if(S.pick){const unit=G.grid[p[1]][p[0]].unit;if(unit)void send({action:'pick',id:unit.id});}
  else void send({action:'tile',x:p[0],y:p[1]});
});
document.addEventListener('keydown',ev=>{
  if(!S)return;
  if((ev.key==='Enter'||ev.key===' ')&&ev.target.matches('.chip[role=button]')){ev.preventDefault();ev.target.click();return;}
  if(ev.code==='Space'&&S.phase==='ready'&&!ev.target.closest('button')){ev.preventDefault();void send({action:'start'});}
  if(ev.key==='Escape'&&S.pick)void send({action:'cancelPick'});
  else if(ev.key==='Escape'){selectedUnitId=null;S.hover=null;towerListSignature='';renderTowerCards();renderInspect();}
});
function resize(){
  const board=$('board'),style=getComputedStyle(board);
  const w=board.clientWidth-(parseFloat(style.paddingLeft)||0)-(parseFloat(style.paddingRight)||0);T=Math.max(8,Math.floor(Math.min(w,735)/N));
  viewWidth=N*T;viewHeight=viewWidth;
  const dpr=window.devicePixelRatio||1;cv.width=viewWidth*dpr;cv.height=viewHeight*dpr;
  cv.style.width=viewWidth+'px';cv.style.height=viewHeight+'px';ctx.setTransform(dpr,0,0,dpr,0,0);
}
window.addEventListener('resize',resize);
let previousDraw=0;
function loop(now){frameDt=Math.min(.05,Math.max(0,(now-previousDraw)/1000));previousDraw=now;if(S)draw(now/1000);requestAnimationFrame(loop);}
resize();requestAnimationFrame(loop);
if(location.protocol==='file:'){
  $('backendStatus').textContent='Oyunu http://localhost:5080 adresinden aç.';
  $('phase').textContent='C# sunucusuna bağlantı gerekiyor.';
}else void connect();
})();
